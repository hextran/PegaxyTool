﻿using System.Diagnostics;

namespace PEGAXY
{
    public partial class form_tool_pegaxy : Form
    {
        public form_tool_pegaxy()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void form_tool_pegaxy_Load(object sender, EventArgs e)
        {
            // chỉnh status chạy hay chưa
            mode_status_run(0);
            
            
        }

        /// <summary>
        /// Chế độ chạy
        /// </summary>
        /// <param name="mode">0. là chưa chạy , different. đã chạy </param>
        private void mode_status_run(int mode)
        {
            if (mode == 0)
            {
                lbl_trangthai.Text = "Chưa chạy";
                lbl_trangthai.ForeColor = Color.Red;
            } else
            {
                lbl_trangthai.Text = "Đã chạy";
                lbl_trangthai.ForeColor = Color.Green;
            }

        }

        /// <summary>
        /// Open gui setup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_setup_Click(object sender, EventArgs e)
        {
            // mở form setup
            giaodien_setup setup = new giaodien_setup();
            setup.Show();
        }

        /// <summary>
        /// Open gui setting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_setting_Click(object sender, EventArgs e)
        {
            // mở form setting
            giaodien_setting setting = new giaodien_setting();
            setting.Show();
        }

        /// <summary>
        /// Open gui run
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btn_run_Click(object sender, EventArgs e)
        {
            // mở form setting
            giaodien_run run = new giaodien_run();
            run.Show();
        }
    }
}