﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class giaodien_setting : Form
    {
        static profile extension_profile = new profile();
        static setting setting = new setting(); 
        public giaodien_setting()
        {
            InitializeComponent();
        }

        private void giaodien_setting_Load(object sender, EventArgs e)
        {
            try
            {
                nud_delaybrowser.Value = Convert.ToInt32(setting.load_browser_delay());
                nud_delayreload.Value = Convert.ToInt32(setting.load_reload_delay());
                
               
            } catch { }
            Load_profile();
        }

        // load profile
        private void Load_profile()
        {
            lb_profile.Items.Clear();
            // lấy list profile rồi hiện ra màn hình
            foreach (string json in extension_profile.get_all_profile())
            {
                JObject j_decode = JObject.Parse(json);
                string meta_wallet = (string)j_decode["meta_wallet"];
                lb_profile.Items.Add(j_decode);
                lb_profile.DisplayMember = "meta_wallet";
            }
        }


        // check chonj luwaj
        private void lb_profile_SelectedIndexChanged(object sender, EventArgs e)
        {
            JObject json = (JObject)lb_profile.Items[lb_profile.SelectedIndex];
            string info_view = (string)"Đường dẫn profile: " + json["profile_path"] + "\nProxy sử dụng: " + json["proxy"] + "\nVí meta: " + json["meta_wallet"] + "\nPass meta: " + json["meta_pass"] + "\nApi giải captcha sử dụng: " + json["api2_cap"] + "\nRent %: " + json["rent_ngua"] + "\nTạo vào lúc: " + json["time_create"];
            MessageBox.Show(info_view, "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        // opem form edit phan tram
        private void btn_edit_phantram_Click(object sender, EventArgs e)
        {
            // lay thong tin doi tuong
            JObject json = (JObject)lb_profile.Items[lb_profile.SelectedIndex];
            string rentngua = (string)json["rent_ngua"];
            string[] split = rentngua.Split("-");
            int min = Convert.ToInt32(split[0]);
            int max = Convert.ToInt32(split[1]);

      
            string old_char = (string)json["profile_path"] + "|" + json["proxy"] + "|" + json["meta_wallet"] + "|" + json["meta_pass"] + "|" + json["api2_cap"] + "|" + json["time_create"] + "|" + json["rent_ngua"];
            string new_char = (string)json["profile_path"] + "|" + json["proxy"] + "|" + json["meta_wallet"] + "|" + json["meta_pass"] + "|" + json["api2_cap"] + "|" + json["time_create"] + "|";
            // mo form edit
            edit_phantram edit = new edit_phantram(min, max, old_char, new_char);
            edit.Show();
           
        }


        // chinh sua them
        private void btn_edit_more_Click(object sender, EventArgs e)
        {
            // lay thong tin doi tuong
            JObject json = (JObject)lb_profile.Items[lb_profile.SelectedIndex];
            string rentngua = (string)json["rent_ngua"];
            string[] split = rentngua.Split("-");
            int min = Convert.ToInt32(split[0]);
            int max = Convert.ToInt32(split[1]);


            string old_char = (string)json["profile_path"] + "|" + json["proxy"] + "|" + json["meta_wallet"] + "|" + json["meta_pass"] + "|" + json["api2_cap"] + "|" + json["time_create"] + "|" + json["rent_ngua"];
            editmore eidt = new editmore(old_char);
            eidt.Show();
        }

        private void btn_reload_Click(object sender, EventArgs e)
        {
            Load_profile();
        }

        private void nud_delaybrowser_ValueChanged(object sender, EventArgs e)
        {
            File.WriteAllText("delaybrowser.txt",nud_delaybrowser.Value.ToString());
        }

        private void nud_delayreload_ValueChanged(object sender, EventArgs e)
        {
            File.WriteAllText("delayreload.txt", nud_delayreload.Value.ToString());
        }


        // them image auto click
        private void btn_addimage_Click(object sender, EventArgs e)
        {
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
