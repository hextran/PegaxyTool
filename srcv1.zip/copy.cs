﻿using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class copy : Form
    {
        static string contents_meta = ""; // nội dụng ví menta
        static string contents_pass = ""; // nội dung mật khẩu
        static string save_profile = ""; // thông tin lưu 
        static string rent_ngua = ""; // phaanf trawm bawts nguwa
        static ChromeDriver driverz = null;
        /// <summary>
        /// Thêm profile
        /// </summary>
        /// <param name="meta_wallet">ví meta</param>
        /// <param name="meta_pass">pass meta</param>
        /// <param name="profile_name">tên profile</param>
        /// <param name="proxy">proxy</param>
        /// <param name="apikey_2captcha">api 2cap</param>
        /// <param name="local_profile">chỗ lưu profile</param>
        public copy(string meta_wallet, string meta_pass , string profile_name, string proxy, string apikey_2captcha, string local_profile, ChromeDriver driver, string min , string max)
        {
            contents_meta = meta_wallet;
            contents_pass = meta_pass;
            driverz = driver;
            rent_ngua = "|" + min + "-" + max;
            save_profile = local_profile + "\\" + profile_name + "|" + proxy + "|" + meta_wallet + "|" + meta_pass + "|" + apikey_2captcha;
            InitializeComponent();
        }

        private void copy_Load(object sender, EventArgs e)
        {
            lb_contents.Text = contents_meta + "|" + contents_pass;
            File.WriteAllText("check.txt", "1");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(contents_meta);
        
        }

        private void btn_copypass_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(contents_pass);
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            Clipboard.SetText("https://play.pegaxy.io/renting?tab=share-profit");
        }

        private void btn_save_profile_Click(object sender, EventArgs e)
        {
            File.AppendAllText("profile_list.txt", save_profile + "|" + DateTime.Now+rent_ngua+"\n");
            driverz.Quit();
            MessageBox.Show("Lưu thành công profile!","Thông tin",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }
    }
}
