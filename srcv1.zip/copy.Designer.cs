﻿namespace PEGAXY
{
    partial class copy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lb_contents = new System.Windows.Forms.Label();
            this.btn_copywallet = new System.Windows.Forms.Button();
            this.btn_copypass = new System.Windows.Forms.Button();
            this.btn_ok = new System.Windows.Forms.Button();
            this.btn_save_profile = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(291, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Do hệ thống chặn nên bạn chịu khó copy bỏ vào nhé.";
            // 
            // lb_contents
            // 
            this.lb_contents.AutoSize = true;
            this.lb_contents.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lb_contents.ForeColor = System.Drawing.Color.Green;
            this.lb_contents.Location = new System.Drawing.Point(12, 33);
            this.lb_contents.Name = "lb_contents";
            this.lb_contents.Size = new System.Drawing.Size(92, 25);
            this.lb_contents.TabIndex = 1;
            this.lb_contents.Text = "Contents";
            // 
            // btn_copywallet
            // 
            this.btn_copywallet.Location = new System.Drawing.Point(12, 72);
            this.btn_copywallet.Name = "btn_copywallet";
            this.btn_copywallet.Size = new System.Drawing.Size(78, 23);
            this.btn_copywallet.TabIndex = 2;
            this.btn_copywallet.Text = "Copy wallet";
            this.btn_copywallet.UseVisualStyleBackColor = true;
            this.btn_copywallet.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_copypass
            // 
            this.btn_copypass.Location = new System.Drawing.Point(96, 72);
            this.btn_copypass.Name = "btn_copypass";
            this.btn_copypass.Size = new System.Drawing.Size(75, 23);
            this.btn_copypass.TabIndex = 3;
            this.btn_copypass.Text = "Copy Pass";
            this.btn_copypass.UseVisualStyleBackColor = true;
            this.btn_copypass.Click += new System.EventHandler(this.btn_copypass_Click);
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(177, 72);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(157, 23);
            this.btn_ok.TabIndex = 4;
            this.btn_ok.Text = "Copy Url Pegaxy";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // btn_save_profile
            // 
            this.btn_save_profile.Location = new System.Drawing.Point(12, 101);
            this.btn_save_profile.Name = "btn_save_profile";
            this.btn_save_profile.Size = new System.Drawing.Size(322, 23);
            this.btn_save_profile.TabIndex = 5;
            this.btn_save_profile.Text = "Lưu lại profile , nếu đã hoàn thành";
            this.btn_save_profile.UseVisualStyleBackColor = true;
            this.btn_save_profile.Click += new System.EventHandler(this.btn_save_profile_Click);
            // 
            // copy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(346, 128);
            this.Controls.Add(this.btn_save_profile);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.btn_copypass);
            this.Controls.Add(this.btn_copywallet);
            this.Controls.Add(this.lb_contents);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "copy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "copy";
            this.Load += new System.EventHandler(this.copy_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label lb_contents;
        private Button btn_copywallet;
        private Button btn_copypass;
        private Button btn_ok;
        private Button btn_save_profile;
    }
}