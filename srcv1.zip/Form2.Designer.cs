﻿namespace PEGAXY
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_move_meta = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_tile_ne = new System.Windows.Forms.Button();
            this.btn_trungbinh_size = new System.Windows.Forms.Button();
            this.btn_stop_threads = new System.Windows.Forms.Button();
            this.btn_auto_action = new System.Windows.Forms.Button();
            this.btn_maxsize = new System.Windows.Forms.Button();
            this.btn_minsize = new System.Windows.Forms.Button();
            this.btn_mcopy = new System.Windows.Forms.Button();
            this.btn_copy_pass = new System.Windows.Forms.Button();
            this.btn_move_url_pegaxy = new System.Windows.Forms.Button();
            this.txtb_contents = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lsb_threads = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn_move_meta);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.btn_tile_ne);
            this.groupBox1.Controls.Add(this.btn_trungbinh_size);
            this.groupBox1.Controls.Add(this.btn_stop_threads);
            this.groupBox1.Controls.Add(this.btn_auto_action);
            this.groupBox1.Controls.Add(this.btn_maxsize);
            this.groupBox1.Controls.Add(this.btn_minsize);
            this.groupBox1.Controls.Add(this.btn_mcopy);
            this.groupBox1.Controls.Add(this.btn_copy_pass);
            this.groupBox1.Controls.Add(this.btn_move_url_pegaxy);
            this.groupBox1.Controls.Add(this.txtb_contents);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(297, 467);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Info view";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // btn_move_meta
            // 
            this.btn_move_meta.Location = new System.Drawing.Point(6, 400);
            this.btn_move_meta.Name = "btn_move_meta";
            this.btn_move_meta.Size = new System.Drawing.Size(158, 23);
            this.btn_move_meta.TabIndex = 20;
            this.btn_move_meta.Text = "Move MetaExtension";
            this.btn_move_meta.UseVisualStyleBackColor = true;
            this.btn_move_meta.Click += new System.EventHandler(this.btn_move_meta_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(11, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 19;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btn_tile_ne
            // 
            this.btn_tile_ne.Location = new System.Drawing.Point(170, 400);
            this.btn_tile_ne.Name = "btn_tile_ne";
            this.btn_tile_ne.Size = new System.Drawing.Size(121, 23);
            this.btn_tile_ne.TabIndex = 18;
            this.btn_tile_ne.Text = "Xem tỉ lệ trên trang";
            this.btn_tile_ne.UseVisualStyleBackColor = true;
            this.btn_tile_ne.Click += new System.EventHandler(this.btn_tile_ne_Click);
            // 
            // btn_trungbinh_size
            // 
            this.btn_trungbinh_size.Location = new System.Drawing.Point(188, 342);
            this.btn_trungbinh_size.Name = "btn_trungbinh_size";
            this.btn_trungbinh_size.Size = new System.Drawing.Size(103, 23);
            this.btn_trungbinh_size.TabIndex = 16;
            this.btn_trungbinh_size.Text = "average brw";
            this.btn_trungbinh_size.UseVisualStyleBackColor = true;
            this.btn_trungbinh_size.Click += new System.EventHandler(this.btn_trungbinh_size_Click);
            // 
            // btn_stop_threads
            // 
            this.btn_stop_threads.Location = new System.Drawing.Point(133, 372);
            this.btn_stop_threads.Name = "btn_stop_threads";
            this.btn_stop_threads.Size = new System.Drawing.Size(158, 23);
            this.btn_stop_threads.TabIndex = 15;
            this.btn_stop_threads.Text = "Ngưng luồng auto này";
            this.btn_stop_threads.UseVisualStyleBackColor = true;
            this.btn_stop_threads.Click += new System.EventHandler(this.btn_stop_threads_Click);
            // 
            // btn_auto_action
            // 
            this.btn_auto_action.Location = new System.Drawing.Point(6, 371);
            this.btn_auto_action.Name = "btn_auto_action";
            this.btn_auto_action.Size = new System.Drawing.Size(121, 23);
            this.btn_auto_action.TabIndex = 14;
            this.btn_auto_action.Text = "Tiến hành auto";
            this.btn_auto_action.UseVisualStyleBackColor = true;
            this.btn_auto_action.Click += new System.EventHandler(this.btn_auto_action_Click);
            // 
            // btn_maxsize
            // 
            this.btn_maxsize.Location = new System.Drawing.Point(101, 343);
            this.btn_maxsize.Name = "btn_maxsize";
            this.btn_maxsize.Size = new System.Drawing.Size(81, 23);
            this.btn_maxsize.TabIndex = 13;
            this.btn_maxsize.Text = "Maxsize brw";
            this.btn_maxsize.UseVisualStyleBackColor = true;
            this.btn_maxsize.Click += new System.EventHandler(this.btn_maxsize_Click);
            // 
            // btn_minsize
            // 
            this.btn_minsize.Location = new System.Drawing.Point(6, 342);
            this.btn_minsize.Name = "btn_minsize";
            this.btn_minsize.Size = new System.Drawing.Size(89, 23);
            this.btn_minsize.TabIndex = 12;
            this.btn_minsize.Text = "Minsize brw";
            this.btn_minsize.UseVisualStyleBackColor = true;
            this.btn_minsize.Click += new System.EventHandler(this.btn_minsize_Click);
            // 
            // btn_mcopy
            // 
            this.btn_mcopy.Location = new System.Drawing.Point(182, 313);
            this.btn_mcopy.Name = "btn_mcopy";
            this.btn_mcopy.Size = new System.Drawing.Size(109, 23);
            this.btn_mcopy.TabIndex = 11;
            this.btn_mcopy.Text = "M-Copy (OFF)";
            this.btn_mcopy.UseVisualStyleBackColor = true;
            this.btn_mcopy.Click += new System.EventHandler(this.btn_mcopy_Click);
            // 
            // btn_copy_pass
            // 
            this.btn_copy_pass.Location = new System.Drawing.Point(101, 313);
            this.btn_copy_pass.Name = "btn_copy_pass";
            this.btn_copy_pass.Size = new System.Drawing.Size(75, 23);
            this.btn_copy_pass.TabIndex = 10;
            this.btn_copy_pass.Text = "Copy Pass";
            this.btn_copy_pass.UseVisualStyleBackColor = true;
            this.btn_copy_pass.Click += new System.EventHandler(this.btn_copy_pass_Click);
            // 
            // btn_move_url_pegaxy
            // 
            this.btn_move_url_pegaxy.Location = new System.Drawing.Point(6, 313);
            this.btn_move_url_pegaxy.Name = "btn_move_url_pegaxy";
            this.btn_move_url_pegaxy.Size = new System.Drawing.Size(89, 23);
            this.btn_move_url_pegaxy.TabIndex = 9;
            this.btn_move_url_pegaxy.Text = "Move Pegaxy";
            this.btn_move_url_pegaxy.UseVisualStyleBackColor = true;
            this.btn_move_url_pegaxy.Click += new System.EventHandler(this.btn_move_url_pegaxy_Click);
            // 
            // txtb_contents
            // 
            this.txtb_contents.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtb_contents.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_contents.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtb_contents.Location = new System.Drawing.Point(6, 62);
            this.txtb_contents.Multiline = true;
            this.txtb_contents.Name = "txtb_contents";
            this.txtb_contents.Size = new System.Drawing.Size(285, 245);
            this.txtb_contents.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(285, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "Thông tin";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lsb_threads);
            this.groupBox2.Location = new System.Drawing.Point(315, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(216, 401);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ListP";
            // 
            // lsb_threads
            // 
            this.lsb_threads.FormattingEnabled = true;
            this.lsb_threads.ItemHeight = 15;
            this.lsb_threads.Location = new System.Drawing.Point(6, 22);
            this.lsb_threads.Name = "lsb_threads";
            this.lsb_threads.Size = new System.Drawing.Size(204, 364);
            this.lsb_threads.TabIndex = 0;
            this.lsb_threads.SelectedIndexChanged += new System.EventHandler(this.lsb_threads_SelectedIndexChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 491);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUAN LY";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private GroupBox groupBox2;
        private ListBox lsb_threads;
        private Button btn_stop_threads;
        private Button btn_auto_action;
        private Button btn_maxsize;
        private Button btn_minsize;
        private Button btn_mcopy;
        private Button btn_copy_pass;
        private Button btn_move_url_pegaxy;
        private TextBox txtb_contents;
        private Button btn_trungbinh_size;
        private Button btn_tile_ne;
        private Button btn_move_meta;
        private Button button1;
    }
}