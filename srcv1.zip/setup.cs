﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEGAXY
{
    internal class setup
    {
        static support support = new support(); // tạo support
       
        /// <summary>
        /// Hàm tạo profile
        /// </summary>
        /// <param name="profile_path">Đường dẫn profile</param>
        /// <param name="proxy">Proxy http</param>
        /// <param name="meta_wallet">Ví meta</param>
        /// <param name="pass_meta">Pass meta</param>
        public ChromeDriver create_profile(string profile_path, string proxy, string meta_wallet, string pass_meta, string api2_captcha, string min, string max,string checkreg = null, ChromeDriver driver = null)
        {
            string name_random = support.random_string(10, 20); // random name profile
           
            try
            {
                driver = install_extension(profile_path+"/"+name_random, proxy); // install extension and create chromedriver
            } catch
            {
                return null;
            }
            //chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/home.html#initialize/welcome
            //chrome-extension://djeopcjpohmfdhnfnckihindolflejda/options/options.html
            Thread.Sleep(2000);
            driver.SwitchTo().Window(driver.WindowHandles[1]);
            string name_url_2cap = driver.Url;
            Thread.Sleep(5000);
            for (int i = 0; i < 2; i++)
            {
                driver.SwitchTo().Window(driver.WindowHandles[0]).Close();
            }
            driver.SwitchTo().Window(driver.WindowHandles[0]);
            
            driver.Navigate().GoToUrl("chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/home.html#initialize/welcome");
            repeated_onions(driver,"//*[@id=\"app-content\"]/div/div[2]/div/div/div/button", "click", "", 20);
            //  MessageBox.Show("Hãy làm thủ công ở bước này, do hệ thống không thể auto được!", "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            // check ok form copy
            //   copy c = new copy(meta_wallet, pass_meta, name_random, proxy, api2_captcha, profile_path, driver, min, max);
            // c.Show();
            repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div/div[2]/div/div[2]/div[1]/button", "click", "", 20);
            repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div/div/div[5]/div[1]/footer/button[2]", "click", "", 20);
            repeated_onions(driver, "//*[@id=\"create-new-vault__srp\"]", "input", meta_wallet, 20);
            repeated_onions(driver, "//*[@id=\"password\"]", "input", pass_meta, 20);
            repeated_onions(driver, "//*[@id=\"confirm-password\"]", "input", pass_meta, 20);
           // MessageBox.Show("hihi");
            repeated_onions(driver, "//*[@id=\"create-new-vault__terms-checkbox\"]", "click", "", 20);
            repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div/div[2]/form/button", "click", "", 20);
            repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div/button", "click", "", 20);
            
           
            driver.Navigate().GoToUrl(name_url_2cap);
            repeated_onions(driver, "/html/body/div/div[1]/table/tbody/tr[1]/td[2]/input", "input", api2_captcha, 20);
            repeated_onions(driver, "//*[@id=\"connect\"]", "click", "", 20);
            string rent_ngua = "|" + min + "-" + max;
            if(checkreg == "")
            {
                return driver;
            } else
            {
                string save_profile = profile_path + "\\" + name_random + "|" + proxy + "|" + meta_wallet + "|" + pass_meta + "|" + api2_captcha + "|" + DateTime.Now + rent_ngua + "\n";
                File.AppendAllText("profile_list.txt", save_profile);
                driver.Quit();
            }
            
            return driver;
        }


        private void repeated_onions(ChromeDriver driver, string xpath, string type_action, string text = null, int reapet_count = 5)
        {
            for (int i = 0; i < reapet_count; i++)
            {
                try
                {
                    if (type_action == "click")
                    {
                        driver.FindElement(By.XPath(xpath)).Click();
                    }
                    else if (type_action == "input")
                    {
                        driver.FindElement(By.XPath(xpath)).SendKeys(text);
                    }
                    else if (type_action == "js")
                    {
                        driver.ExecuteScript(xpath);
                    }
                    else if (type_action == "frame")
                    {
                        driver.SwitchTo().Frame(driver.FindElement(By.XPath(xpath)));

                    }
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Thread.Sleep(2000);
                }
            }

        }
        /// <summary>
        /// Thêm extension và tạo driver
        /// </summary>
        /// <param name="path_profile">thêm đường dẫn profile</param>
        /// <param name="proxy">thêm proxy</param>
        public ChromeDriver install_extension (string path_profile, string proxy, string type = null)
        {
            // Head
            var driverService = ChromeDriverService.CreateDefaultService(); // create serivce
            driverService.HideCommandPromptWindow = true; // ẩn cmd
            ChromeOptions options = new ChromeOptions(); // create options
           // options.AddArgument(@"user-data-dir=" + path_profile); // create profile
            options.AddArgument("--disable-images");
            options.AddArgument("--disable-blink-features=AutomationControlled"); // tắt automatic
            if(proxy != "null")
            {
                options.AddArgument(@"--proxy-server=" + proxy); // thêm proxy
            } 
           
                                                           // options.AddExtension("2Captcha-Solver.crx"); // add extension 2captcha solver
            Thread.Sleep(2000);
            if(type == null)
            {
                options.AddExtension("MetaMask.crx"); // add extension MetaMask
                
            }
          
            options.AddArgument("--load-extension=" + Directory.GetCurrentDirectory()+@"\2Captcha-Solver");
            Thread.Sleep(5000);
            ChromeDriver driver = new ChromeDriver(driverService, options); // create drive

            //   File.AppendAllText("list_profile.txt", name_random + "\n"); // ghi profile vào list_profile để sau này lấy 
            return driver;


        }

        /// <summary>
        /// Check proxy
        /// </summary>
        /// <param name="proxy">đưa proxy vào</param>
        public void proxy_checker (string proxy)
        {
            var driverService = ChromeDriverService.CreateDefaultService(); // create serivce
            driverService.HideCommandPromptWindow = true; // ẩn cmd
            ChromeOptions options = new ChromeOptions(); // tạo options
            options.AddArgument("--proxy-server=" + proxy); // thêm proxy
          //  options.AddArgument(@"user-data-dir=" + @"D:\Downloads\profile\TTKPXMSOXQH");
           // options.AddExtension("MetaMask.crx"); // add extension MetaMask
            options.AddArgument("headless"); // ẩn chrome
            ChromeDriver driver = new ChromeDriver(driverService,options); // tạo chromedriver với service và options đã tạo
           // MessageBox.Show("");
            try
            {
                driver.Navigate().GoToUrl("https://google.com"); // go tô đến google.com để check proxy
                Thread.Sleep(1000);
                driver.Quit();
                MessageBox.Show("Proxy hoạt động tốt!","Thành Công",MessageBoxButtons.OK,MessageBoxIcon.Information); // nghỉ 1s rồi báo thành công
            }
            catch
            {
                driver.Quit();
                MessageBox.Show("Proxy lỗi!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error); // báo lỗi nếu không connect được đến proxy
            }
           

          
        }

        /// <summary>
        /// lưu lại path profile
        /// </summary>
        /// <param name="path">đường dẫn profile</param>
        public void save_path_profile (string path)
        {
            File.WriteAllText("luupath.txt", path);
        }

        /// <summary>
        /// Lấy ra path profile
        /// </summary>
        /// <returns></returns>
        public string get_path_profile()
        {
            return File.ReadAllText("luupath.txt");
        }

        /// <summary>
        /// Lưu api key 2captcha
        /// </summary>
        /// <param name="apikey">apikey 2captcha</param>
        public void save_api_2cap (string apikey)
        {
            File.WriteAllText("apikey.txt", apikey);
        }

        /// <summary>
        /// get apikey 2captcha
        /// </summary>
        /// <returns></returns>
        public string get_api_2cap()
        {
            return File.ReadAllText("apikey.txt");
        }
    }
}
