﻿namespace PEGAXY
{
    partial class giaodien_setup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_max = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.nud_min = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.txb_apikey_2captcha = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_create_profile = new System.Windows.Forms.Button();
            this.txb_pass_metamask = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_metamask_wallet = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_checkproxy = new System.Windows.Forms.Button();
            this.txb_proxy = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_delete_profile = new System.Windows.Forms.Button();
            this.btn_reload = new System.Windows.Forms.Button();
            this.lsb_profile = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_max)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_min)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Setup GUI";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_max);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.nud_min);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txb_apikey_2captcha);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btn_create_profile);
            this.groupBox1.Controls.Add(this.txb_pass_metamask);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.txb_metamask_wallet);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btn_checkproxy);
            this.groupBox1.Controls.Add(this.txb_proxy);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(244, 391);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "TẠO PROFILE";
            // 
            // nud_max
            // 
            this.nud_max.Location = new System.Drawing.Point(150, 189);
            this.nud_max.Name = "nud_max";
            this.nud_max.Size = new System.Drawing.Size(56, 23);
            this.nud_max.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(109, 191);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Max";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 191);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Min";
            // 
            // nud_min
            // 
            this.nud_min.Location = new System.Drawing.Point(47, 189);
            this.nud_min.Name = "nud_min";
            this.nud_min.Size = new System.Drawing.Size(56, 23);
            this.nud_min.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 171);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 15);
            this.label6.TabIndex = 14;
            this.label6.Text = "Max min % rent ngua";
            // 
            // txb_apikey_2captcha
            // 
            this.txb_apikey_2captcha.Location = new System.Drawing.Point(6, 333);
            this.txb_apikey_2captcha.Name = "txb_apikey_2captcha";
            this.txb_apikey_2captcha.Size = new System.Drawing.Size(232, 23);
            this.txb_apikey_2captcha.TabIndex = 13;
            this.txb_apikey_2captcha.TextChanged += new System.EventHandler(this.txb_apikey_2captcha_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 315);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 15);
            this.label8.TabIndex = 12;
            this.label8.Text = "Api key 2captcha";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(441, 514);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "label5";
            // 
            // btn_create_profile
            // 
            this.btn_create_profile.Location = new System.Drawing.Point(6, 362);
            this.btn_create_profile.Name = "btn_create_profile";
            this.btn_create_profile.Size = new System.Drawing.Size(232, 23);
            this.btn_create_profile.TabIndex = 7;
            this.btn_create_profile.Text = "Tạo profile";
            this.btn_create_profile.UseVisualStyleBackColor = true;
            this.btn_create_profile.Click += new System.EventHandler(this.btn_create_profile_Click);
            // 
            // txb_pass_metamask
            // 
            this.txb_pass_metamask.Location = new System.Drawing.Point(6, 145);
            this.txb_pass_metamask.Name = "txb_pass_metamask";
            this.txb_pass_metamask.Size = new System.Drawing.Size(232, 23);
            this.txb_pass_metamask.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(6, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(238, 35);
            this.label4.TabIndex = 5;
            this.label4.Text = "Nhập pass set cho ví Metamask ( ghi random để nó tự động random pass )";
            // 
            // txb_metamask_wallet
            // 
            this.txb_metamask_wallet.Location = new System.Drawing.Point(6, 81);
            this.txb_metamask_wallet.Name = "txb_metamask_wallet";
            this.txb_metamask_wallet.Size = new System.Drawing.Size(232, 23);
            this.txb_metamask_wallet.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(146, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nhập tài khoản Metamask";
            // 
            // btn_checkproxy
            // 
            this.btn_checkproxy.Location = new System.Drawing.Point(150, 37);
            this.btn_checkproxy.Name = "btn_checkproxy";
            this.btn_checkproxy.Size = new System.Drawing.Size(88, 23);
            this.btn_checkproxy.TabIndex = 2;
            this.btn_checkproxy.Text = "Check Proxy";
            this.btn_checkproxy.UseVisualStyleBackColor = true;
            this.btn_checkproxy.Click += new System.EventHandler(this.btn_checkproxy_Click);
            // 
            // txb_proxy
            // 
            this.txb_proxy.Location = new System.Drawing.Point(6, 37);
            this.txb_proxy.Name = "txb_proxy";
            this.txb_proxy.Size = new System.Drawing.Size(138, 23);
            this.txb_proxy.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(185, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Nhập proxy mua trên proxyv6.net";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_delete_profile);
            this.groupBox2.Controls.Add(this.btn_reload);
            this.groupBox2.Controls.Add(this.lsb_profile);
            this.groupBox2.Location = new System.Drawing.Point(265, 47);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(244, 391);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "QUẢN LÝ PROFILE";
            // 
            // btn_delete_profile
            // 
            this.btn_delete_profile.Location = new System.Drawing.Point(163, 362);
            this.btn_delete_profile.Name = "btn_delete_profile";
            this.btn_delete_profile.Size = new System.Drawing.Size(75, 23);
            this.btn_delete_profile.TabIndex = 2;
            this.btn_delete_profile.Text = "Xóa";
            this.btn_delete_profile.UseVisualStyleBackColor = true;
            this.btn_delete_profile.Click += new System.EventHandler(this.btn_delete_profile_Click);
            // 
            // btn_reload
            // 
            this.btn_reload.Location = new System.Drawing.Point(6, 362);
            this.btn_reload.Name = "btn_reload";
            this.btn_reload.Size = new System.Drawing.Size(75, 23);
            this.btn_reload.TabIndex = 1;
            this.btn_reload.Text = "TẢI LẠI";
            this.btn_reload.UseVisualStyleBackColor = true;
            this.btn_reload.Click += new System.EventHandler(this.btn_reload_Click);
            // 
            // lsb_profile
            // 
            this.lsb_profile.FormattingEnabled = true;
            this.lsb_profile.ItemHeight = 15;
            this.lsb_profile.Location = new System.Drawing.Point(6, 22);
            this.lsb_profile.Name = "lsb_profile";
            this.lsb_profile.Size = new System.Drawing.Size(232, 334);
            this.lsb_profile.TabIndex = 0;
            this.lsb_profile.SelectedIndexChanged += new System.EventHandler(this.lsb_profile_SelectedIndexChanged);
            this.lsb_profile.SelectedValueChanged += new System.EventHandler(this.lsb_profile_SelectedValueChanged);
            // 
            // giaodien_setup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "giaodien_setup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Giao diện setup";
            this.Load += new System.EventHandler(this.giaodien_setup_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_max)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_min)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private Label label3;
        private Button btn_checkproxy;
        private TextBox txb_proxy;
        private Label label2;
        private GroupBox groupBox2;
        private Button btn_delete_profile;
        private Button btn_reload;
        private ListBox lsb_profile;
        private Label label5;
        private Button btn_create_profile;
        private TextBox txb_pass_metamask;
        private Label label4;
        private TextBox txb_metamask_wallet;
        private TextBox txb_apikey_2captcha;
        private Label label8;
        private NumericUpDown nud_max;
        private Label label10;
        private Label label9;
        private NumericUpDown nud_min;
        private Label label6;
    }
}