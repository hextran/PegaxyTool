﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class giaodien_setup : Form
    {
        static setup extension_setup = new setup(); // create extension setup
        static support support = new support(); // create support
        static profile extension_profile = new profile();
        public giaodien_setup()
        {
            InitializeComponent();
        }

        private void giaodien_setup_Load(object sender, EventArgs e)
        {
            // load profile 
          

            // load apikey 2captcha
            try
            {
                txb_apikey_2captcha.Text = extension_setup.get_api_2cap();
            }
            catch { }
            // load profile
            try
            {
                Load_profile();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "lỖI");
            }
        }


        // Load profile
        private void Load_profile()
        {
            lsb_profile.Items.Clear();
            // lấy list profile rồi hiện ra màn hình
            foreach (string json in extension_profile.get_all_profile())
            {
                JObject j_decode = JObject.Parse(json);
                string meta_wallet = (string)j_decode["meta_wallet"];
                lsb_profile.Items.Add(j_decode);
                lsb_profile.DisplayMember = "meta_wallet";
            }
        }
        // auto save profile
        private void txb_profile_TextChanged(object sender, EventArgs e)
        {
            extension_setup.save_path_profile("/khongco/"); // lưu profile
        }


        // action create profile
        private void btn_create_profile_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            if(txb_apikey_2captcha.Text == "" || txb_metamask_wallet.Text == "" || txb_pass_metamask.Text == "" || txb_proxy.Text == "" || nud_max.Value < nud_min.Value)
            {

                MessageBox.Show("Bạn đã nhập thiếu gì đó, vui lòng nhập lại", "Lỗi!", MessageBoxButtons.OK, MessageBoxIcon.Error); // báo lỗi nếu nhập thiếu
                this.Enabled = true;
            } else
            {
                if(txb_pass_metamask.Text == "random") // check random
                {
                    txb_pass_metamask.Text = support.random_string(20, 30); // gen pass
                }
                var check = extension_setup.create_profile("/khongco/", txb_proxy.Text, txb_metamask_wallet.Text, txb_pass_metamask.Text, txb_apikey_2captcha.Text, Convert.ToString(nud_min.Value), Convert.ToString(nud_max.Value)); // create profile
                this.Enabled = true;
                //    if (check == null) // kiểm tra
                //   {
                //     MessageBox.Show("Lỗi tạo profile rồi!, kiểm tra lại hoạc báo team để được hỗ trợ!"); // báo lỗi 
                //      this.Enabled = true;
                //  } else
                //   {
                //       this.Enabled = true;
                //    }
            }
            
        }

        // auto save key api
        private void txb_apikey_2captcha_TextChanged(object sender, EventArgs e)
        {
            extension_setup.save_api_2cap(txb_apikey_2captcha.Text); // lưu apikey 
        }

        // check proxy
        private void btn_checkproxy_Click(object sender, EventArgs e)
        {
            // mở thread checker proxy
            Thread thread = new Thread(() =>
            {
                thread_checker_proxy();
            });
            thread.Start();
        }

        //thread checker proxy
        private void thread_checker_proxy()
        {

            if (txb_proxy.Text.Contains(":")) // kiểm tra định dạng
            {
                extension_setup.proxy_checker(txb_proxy.Text); // gọi hàm và check proxy 
            }
            else
            {
                MessageBox.Show("Proxy không dúng định dạng , định dạng yêu cầu ip:port", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error); // báo lỗi định dạng
            }

        }

        /// <summary>
        /// Hiển thị thông tin profile khi chọn
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void lsb_profile_SelectedValueChanged(object sender, EventArgs e)
        {
          
        }

        private void btn_delete_profile_Click(object sender, EventArgs e)
        {
            try
            {
                extension_profile.delete_profile((JObject)lsb_profile.Items[lsb_profile.SelectedIndex]);
                Load_profile();
            } catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi gì đó, chi tiết : " + ex, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        // khi nhấn vào reload sẽ tự reload lại profile
        private void btn_reload_Click(object sender, EventArgs e)
        {
            Load_profile();
        }

        private void lsb_profile_SelectedIndexChanged(object sender, EventArgs e)
        {
            
             JObject json = (JObject)lsb_profile.Items[lsb_profile.SelectedIndex];
             string info_view = (string)"Đường dẫn profile: " + json["profile_path"] + "\nProxy sử dụng: " + json["proxy"] + "\nVí meta: " + json["meta_wallet"] + "\nPass meta: " + json["meta_pass"] + "\nApi giải captcha sử dụng: " + json["api2_cap"] + "\nRent %: "+json["rent_ngua"]+"\nTạo vào lúc: " + json["time_create"];
             MessageBox.Show(info_view, "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
