﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEGAXY
{
    internal class run
    {
        // create chrome run driver
        public void create_driver(JObject info)
        {
            
        }
    }
}
