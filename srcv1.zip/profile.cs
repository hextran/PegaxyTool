﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace PEGAXY
{
    internal class profile
    {
        static string profile_local = "profile_list.txt"; // name file
        static support support = new support(); // gọi chức năng hỗ trợ

        /// <summary>
        /// get all profile
        /// </summary>
        /// <returns>trả về một list có chứa đầy đủ thông tin</returns>
        public List<string> get_all_profile()
        {
            // đọc file và tạo biến chứa
            string profile_reading = File.ReadAllText(profile_local); 
            List<string> profile = new List<string>();

            // đưa hết về json rồi đưa vào list
            foreach (string line in profile_reading.Split("\n"))
            {
                if(line == "") { } else
                {
                    string[] tach = line.Split("|");
                    // MessageBox.Show(line);
                    var json_object = new
                    {
                        profile_path = tach[0],
                        proxy = tach[1],
                        meta_wallet = tach[2],
                        meta_pass = tach[3],
                        api2_cap = tach[4],
                        time_create = tach[5],
                        rent_ngua = tach[6]
                    };
                    string json = JsonConvert.SerializeObject(json_object);
                    profile.Add(json);
                }

            }

            // trả kết quả
            return profile;
            
        }

        /// <summary>
        /// Xóa profile
        /// </summary>
        /// <param name="json">Đưa jobject vào</param>
        /// <returns></returns>
        public bool delete_profile (JObject json)
        {
            // xóa profile
            bool result = true;
            string infoment = (string)json["profile_path"] + "|" + json["proxy"] + "|" + json["meta_wallet"] + "|" + json["meta_pass"] + "|" + json["api2_cap"] + "|" + json["time_create"] + "|" + json["rent_ngua"];
            string all_profile = File.ReadAllText(profile_local);
            File.WriteAllText(profile_local, all_profile.Replace(infoment, ""));
            support.DeleteFolder((string)json["profile_path"]);
            if (File.ReadAllText(profile_local).Contains(infoment))
            {
                result = false;
            }
            return result;
        }

        /// <summary>
        /// Update profile
        /// </summary>
        /// <param name="old">pROFILE THONG TIN CU</param>
        /// <param name="newstr">THONG TIN MOI</param>
        public void update_profile (string old, string newstr)
        {
            string read_old = File.ReadAllText(profile_local).Replace(old, newstr);
            File.WriteAllText (profile_local, read_old);
        }
    }
}
