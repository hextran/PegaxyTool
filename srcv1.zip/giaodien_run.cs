﻿using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class giaodien_run : Form
    {
        static setup setup = new setup();
        static profile extension_profile = new profile();
        static setting setting = new setting();
        static Dictionary<JObject, ChromeDriver> dict = new Dictionary<JObject, ChromeDriver>();
        public giaodien_run()
        {
            InitializeComponent();
        }

        private void giaodien_run_Load(object sender, EventArgs e)
        {
            Load_profile();
        }

        private void Load_profile()
        {
            lsb_profile.Items.Clear();
            // lấy list profile rồi hiện ra màn hình
            foreach (string json in extension_profile.get_all_profile())
            {
                JObject j_decode = JObject.Parse(json);
                string meta_wallet = (string)j_decode["meta_wallet"];
                lsb_profile.Items.Add(j_decode);
                lsb_profile.DisplayMember = "meta_wallet";
            }
        }

        // accept
        private void btn_accept_profile_Click(object sender, EventArgs e)
        {
            // upload count
            btn_run.Text = "Chạy với " + Convert.ToString(lsb_profile.SelectedIndices.Count) + " acc";
        }

        // run click 
        private void btn_run_Click(object sender, EventArgs e)
        {
            int thread = 0;

            int delay = Convert.ToInt32(setting.load_browser_delay()) * 1000;
            foreach (int local in lsb_profile.SelectedIndices)
            {
                thread++;
                JObject json = (JObject)lsb_profile.Items[local];
                Thread t = new Thread(() =>
                {
                    run_action(json, thread);
                });
                t.Start();
                Thread.Sleep(delay);
            }

            Thread.Sleep(80000);
            Form2 f = new Form2(dict);
            f.Show();
            dict.Clear();
        }


        // run action
        public void run_action(JObject json, int thread)
        {
            while (true)
            {
                ChromeDriver client = null;
                ChromeDriver driver = setup.create_profile((string)json["profile_path"], (string)json["proxy"], (string)json["meta_wallet"], (string)json["meta_pass"], (string)json["api2_cap"], "", "", "", client);
                dict.Add(json, driver);
                Thread.Sleep(5000);
                try
                {
                    var Alert = driver.SwitchTo().Alert();
                    Alert.Accept();
                    Thread.Sleep(1000);
                    driver.Navigate().GoToUrl("https://play.pegaxy.io/renting");

                    repeated_onions(driver, "//*[@id=\"__next\"]/div[1]/div[1]/div/div/ul/li[5]", "click", "", 20);
                    //     driver.ExecuteScript("document.querySelector(\"body > div.fade.modal - alert.modal.show > div > div > div > div.viewAlert > div > div.login - header > p\").innerHTML = \"Đang tiến hành tự động đăng nhập, có thể mất 1 phút hơn\";");
                    repeated_onions(driver, "/html/body/div[3]/div/div/div/div[2]/div/div[2]/div[2]/div[2]/div[2]/span[2]", "click", "", 20);
                    Thread.Sleep(2000);
                    // repeated_onions(driver, "window.open(\"chrome-extension://nkbihfbeogaeaoehlefnkodbefgpgknn/notification.html\", \"_blank\");", "js", "", 10);
                    repeated_onions(driver, "/html/body/div[3]/div/div/div/div[2]/div/div[2]/div[2]/div[2]", "click", "", 10);
                    Thread.Sleep(2000);
                    driver.SwitchTo().Window(driver.WindowHandles[1]);
                    repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div[2]/div/button[2]", "click", "", 20);
                    repeated_onions(driver, "document.querySelector(\"#app-content > div > div.main-container-wrapper > div > div.confirmation-footer > div.confirmation-footer__actions > button.button.btn--rounded.btn-primary\").click();", "js", "", 10);
                    Thread.Sleep(3000);
                    driver.SwitchTo().Window(driver.WindowHandles[1]);
                    repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div[2]/div[3]/div[2]/button[2]", "click", "", 10);
                    repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div[2]/div[2]/div[2]/footer/button[2]", "click", "", 10);
                    Thread.Sleep(3000);
                    driver.SwitchTo().Window(driver.WindowHandles[1]);
                    repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div[3]/button[2]", "click", "", 10);
                    driver.SwitchTo().Window(driver.WindowHandles[0]);
                    Thread.Sleep(5000);

                    driver.Manage().Window.Minimize();
                    break;
                } catch
                {
                    MessageBox.Show("Thử lại lần nữa!");
                
                }
                
               
            }
            


        }

        private void repeated_onions(ChromeDriver driver, string xpath, string type_action, string text = null, int reapet_count = 5)
        {
            for (int i = 0; i < reapet_count; i++)
            {
                try
                {
                    if (type_action == "click")
                    {
                        driver.FindElement(By.XPath(xpath)).Click();
                    }
                    else if (type_action == "input")
                    {
                        driver.FindElement(By.XPath(xpath)).SendKeys(text);
                    }
                    else if (type_action == "js")
                    {
                        driver.ExecuteScript(xpath);
                    }
                    else if (type_action == "frame")
                    {
                        driver.SwitchTo().Frame(driver.FindElement(By.XPath(xpath)));

                    } else if (type_action == "window")
                    {
                        driver.SwitchTo().Window(driver.WindowHandles[Convert.ToInt32(xpath)]);
                    }
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Thread.Sleep(2000);
                }
            }

        }
        private void lsb_profile_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}
