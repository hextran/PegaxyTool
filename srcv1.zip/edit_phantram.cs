﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class edit_phantram : Form
    {
        static int minz = 0;
        static int maxz = 0;
        static setting options = new setting();
        public edit_phantram(int min, int max, string old, string new_char)
        {
            minz = min;
            maxz = max;
            options.old_char = old;
            options.new_char = new_char;
            InitializeComponent();
        }

        private void edit_phantram_Load(object sender, EventArgs e)
        {
            nud_min.Value = minz;
            nud_max.Value = maxz;
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            
            if(nud_max.Value > nud_min.Value)
            {
                options.new_char += Convert.ToString(nud_min.Value) + "-" + Convert.ToString(nud_max.Value);
                options.update_profile();
                MessageBox.Show("Update success!", "Thanh cong", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
        }
    }
}
