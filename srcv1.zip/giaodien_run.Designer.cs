﻿namespace PEGAXY
{
    partial class giaodien_run
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cb_showinfo = new System.Windows.Forms.CheckBox();
            this.btn_run = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_accept_profile = new System.Windows.Forms.Button();
            this.lsb_profile = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Run GUI";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cb_showinfo);
            this.groupBox1.Controls.Add(this.btn_run);
            this.groupBox1.Location = new System.Drawing.Point(12, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 82);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Setting run";
            // 
            // cb_showinfo
            // 
            this.cb_showinfo.AutoSize = true;
            this.cb_showinfo.Location = new System.Drawing.Point(6, 19);
            this.cb_showinfo.Name = "cb_showinfo";
            this.cb_showinfo.Size = new System.Drawing.Size(79, 19);
            this.cb_showinfo.TabIndex = 1;
            this.cb_showinfo.Text = "Show info";
            this.cb_showinfo.UseVisualStyleBackColor = true;
            // 
            // btn_run
            // 
            this.btn_run.Location = new System.Drawing.Point(6, 44);
            this.btn_run.Name = "btn_run";
            this.btn_run.Size = new System.Drawing.Size(188, 23);
            this.btn_run.TabIndex = 0;
            this.btn_run.Text = "Chạy với số acc";
            this.btn_run.UseVisualStyleBackColor = true;
            this.btn_run.Click += new System.EventHandler(this.btn_run_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_accept_profile);
            this.groupBox2.Controls.Add(this.lsb_profile);
            this.groupBox2.Location = new System.Drawing.Point(218, 37);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(270, 401);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Profile run";
            // 
            // btn_accept_profile
            // 
            this.btn_accept_profile.Location = new System.Drawing.Point(6, 372);
            this.btn_accept_profile.Name = "btn_accept_profile";
            this.btn_accept_profile.Size = new System.Drawing.Size(258, 23);
            this.btn_accept_profile.TabIndex = 1;
            this.btn_accept_profile.Text = "Xác nhận chọn profile";
            this.btn_accept_profile.UseVisualStyleBackColor = true;
            this.btn_accept_profile.Click += new System.EventHandler(this.btn_accept_profile_Click);
            // 
            // lsb_profile
            // 
            this.lsb_profile.FormattingEnabled = true;
            this.lsb_profile.ItemHeight = 15;
            this.lsb_profile.Location = new System.Drawing.Point(6, 22);
            this.lsb_profile.Name = "lsb_profile";
            this.lsb_profile.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.lsb_profile.Size = new System.Drawing.Size(258, 334);
            this.lsb_profile.TabIndex = 0;
            this.lsb_profile.SelectedIndexChanged += new System.EventHandler(this.lsb_profile_SelectedIndexChanged);
            // 
            // giaodien_run
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "giaodien_run";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Giao diện chạy";
            this.Load += new System.EventHandler(this.giaodien_run_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private Button btn_run;
        private GroupBox groupBox2;
        private Button btn_accept_profile;
        private ListBox lsb_profile;
        private CheckBox cb_showinfo;
    }
}