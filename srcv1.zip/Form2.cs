﻿using Newtonsoft.Json.Linq;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class Form2 : Form
    {
        Dictionary<JObject, ChromeDriver> dict = new Dictionary<JObject, ChromeDriver>(); // gán dữ liệu mới
        Dictionary<int,ChromeDriver> dict_value = new Dictionary<int,ChromeDriver>();   // chứa dữ liệu thứ tự chromedriver
        JObject json = null;
        static support sup = new support();
        static ChromeDriver driver_specified = null;
        public Form2(Dictionary<JObject,ChromeDriver> diction)
        {
            dict = diction;
            InitializeComponent();
        }


        // load
        private void Form2_Load(object sender, EventArgs e)
        {
            int stt = -1;
            foreach (KeyValuePair<JObject, ChromeDriver> kvp in dict)
            {
                stt++;
                JObject json = kvp.Key;
                ChromeDriver driver = kvp.Value;
                dict_value.Add(stt,driver);
                lsb_threads.Items.Add(json);
            }
            lsb_threads.DisplayMember = "meta_wallet";
            txtb_contents.Enabled = false;
          //  lsb_threads.SelectedIndex = 0;
        }

        // load thread
        private void btn_reload_threads_Click(object sender, EventArgs e)
        {

        }

        // update info in thongtin
        private void lsb_threads_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                json = (JObject)lsb_threads.Items[lsb_threads.SelectedIndex];
                driver_specified = dict_value[lsb_threads.SelectedIndex];
                string info_view = (string)"Đường dẫn profile: " + json["profile_path"] + "|Proxy sử dụng: " + json["proxy"] + "|Ví meta: " + json["meta_wallet"] + "|Pass meta: " + json["meta_pass"] + "|Api giải captcha sử dụng: " + json["api2_cap"] + "|Rent %: " + json["rent_ngua"] + "|Tạo vào lúc: " + json["time_create"];
                File.WriteAllText("ghitamthoi.txt", info_view);
                txtb_contents.Text = File.ReadAllText("ghitamthoi.txt");
            } catch { }
           
        }


        // move pegaxy
        private void btn_move_url_pegaxy_Click(object sender, EventArgs e)
        {
            try
            {
                driver_specified.Navigate().GoToUrl("https://play.pegaxy.io/renting?tab=share-profit&sortBy=price&sortType=DESC");
            }
            catch { }
            
        }


        // copy pass
        private void btn_copy_pass_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText((string)json["meta_pass"]);
            }
            catch { }
          
        }

        // mcopy
        private void btn_mcopy_Click(object sender, EventArgs e)
        {
            if (txtb_contents.Enabled)
            {
                txtb_contents.Enabled = false;
                btn_mcopy.Text = btn_mcopy.Text.Replace("OFF", "ON");
            } else
            {
                txtb_contents.Enabled = true;
                btn_mcopy.Text = btn_mcopy.Text.Replace("ON", "OFF");
            }
        }
        // THU NHỎ
        private void btn_minsize_Click(object sender, EventArgs e)
        {
            try
            {
                driver_specified.Manage().Window.Minimize();
            } catch { }
           
        }
        // PHÓNG LỚN
        private void btn_maxsize_Click(object sender, EventArgs e)
        {
            try
            {
                driver_specified.Manage().Window.Maximize();
            }
            catch { }
            
        }
        // btn stop
        private void btn_stop_threads_Click(object sender, EventArgs e)
        {
            try
            {
                driver_specified.Quit();
                File.WriteAllText("thread_close.txt", (string)json["profile_path"]);
             
                lsb_threads.Items.RemoveAt(lsb_threads.SelectedIndex);
                txtb_contents.Text = "";
                //driver_specified = null;
            }
            catch { }
           
        }

        // ar size
        private void btn_trungbinh_size_Click(object sender, EventArgs e)
        {
            try
            {
                driver_specified.Manage().Window.Size = new Size(250, 500);
            } catch { }
        }

        // btn action
        private void btn_auto_action_Click(object sender, EventArgs e)
        {
            File.WriteAllText("thread_close.txt","");
            Thread t = new Thread(() =>
            {
                run(driver_specified, json, (string)json["profile_path"]);
            });
            t.Start();
        }
        private bool repeated_onions(ChromeDriver driver, string xpath, string type_action, string text = null, int reapet_count = 5)
        {
            for (int i = 0; i < reapet_count; i++)
            {
                try
                {
                    if (type_action == "click")
                    {
                        driver.FindElement(By.XPath(xpath)).Click();
                        return true;
                    }
                    else if (type_action == "input")
                    {
                        driver.FindElement(By.XPath(xpath)).SendKeys(text);
                        return true;
                    }
                    else if (type_action == "js")
                    {
                        driver.ExecuteScript(xpath);
                        return true;
                    }
                    else if (type_action == "frame")
                    {
                        driver.SwitchTo().Frame(driver.FindElement(By.XPath(xpath)));
                        return true;

                    }
                    else if (type_action == "window")
                    {
                        driver.SwitchTo().Window(driver.WindowHandles[Convert.ToInt32(xpath)]);
                        return true;
                    } else if(type_action == "class")
                    {
                        driver.FindElement(By.ClassName(xpath)).Click();
                        return true;
                    }
                    break;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Thread.Sleep(2000);
                }
            }
            return false;   

        }
        private void run(ChromeDriver driver,JObject json, string path)
        {
          
            while (true)
            {
                List<string> list = new List<string>();
                try
                {
                    string rent_ngua = (string)json["rent_ngua"];
                    string min = rent_ngua.Split("-")[0];
                    string max = rent_ngua.Split("-")[1];
                    driver.ExecuteScript("window.open(\"https://api.pegaxy.io/rent/0?rentMode=SHARE_PROFIT\", \"_blank\");");
                    driver.SwitchTo().Window(driver.WindowHandles[1]);
                    string pagesource = sup.StripHtml(driver.PageSource);
                    JObject json_decode = JObject.Parse(pagesource);
                    driver.SwitchTo().Window(driver.WindowHandles[1]).Close();
                    driver.SwitchTo().Window(driver.WindowHandles[0]);
                    int number_total = Convert.ToInt32(json_decode["total"]);
                    
                  
                    if (number_total > 0)
                    {

                        for (int i = 0; i < number_total; i++)
                        {
                            
                            string rent = (string)json_decode["renting"][i]["price"];
                            string link = (string)json_decode["renting"][i]["id"];
                            int price = Convert.ToInt32(rent) / 10000;
                            if (price <= Convert.ToInt32(max))
                            {
                                if (price >= Convert.ToInt32(min))
                                {
                                    for (int iz = 0; iz < 5; iz++)
                                    {
                                        list.Add("https://play.pegaxy.io/renting/listing/" + link);
                                        driver.Navigate().GoToUrl("https://play.pegaxy.io/renting/listing/" + link);
                                      //  repeated_onions(driver, "document.querySelector(\"#__next > div.root > div.container > div > div > div.bx-content.default > div > div.viewDetail.detailPega > div.viewInfoDetail > div.viewInfo-header > a\").innerHTML = \"Phần mềm đang vận hành để tìm ngựa\";", "js", "", 10);
                                        bool check_status = repeated_onions(driver, "//*[@id=\"__next\"]/div[1]/div[2]/div/div/div[2]/div/div[2]/div[2]/div[3]/div[2]/div/div/div[2]/div/span", "click", "", 10);
                                        if (check_status)
                                        {
                                            bool new_check = repeated_onions(driver, "captcha-solver-info", "class", "", 20);
                                         
                                            if (new_check == true)
                                            {
                                                while (true)
                                                {
                                                    Thread.Sleep(2000);
                                                    if (driver.PageSource.Contains("button-game primary"))
                                                    {
                                                        repeated_onions(driver, "/html/body/div[3]/div/div/div/div[2]/div[3]/div/div/div[2]/div/span", "click", "", 10);

                                                        Thread.Sleep(5000);
                                                        if (driver.PageSource.Contains("color: rgb(255, 123, 0); margin-bottom: 5px; margin-top: 5px;") == true || driver.PageSource.Contains("Response not successful: Received status code 500") == true)
                                                        {
                                                            
                                                            Console.WriteLine("Rent ngựa thất bại rồi!");
                                                            break;
                                                        } else
                                                        {
                                                            int error = 0;
                                                            while (true)
                                                            {
                                                                try
                                                                {
                                                                    driver.SwitchTo().Window(driver.WindowHandles[1]);
                                                                    break;
                                                                }
                                                                catch
                                                                {
                                                                    error++;
                                                                    Thread.Sleep(2000);
                                                                }
                                                                if(error > 10)
                                                                {
                                                                    break;
                                                                }
                                                            }
                                                           
                                                           Thread.Sleep(2000);
                                                               
                                                           repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div[5]/div[3]/footer/button[2]", "click", "", 10);
                                                          
                                                           driver.SwitchTo().Window(driver.WindowHandles[0]);
                                                            int err = 0;
                                                            /***while (true)
                                                            {
                                                                if (driver.PageSource.Contains("COMPLETE"))
                                                                {
                                                                    duangua(driver);
                                                                    driver.SwitchTo().Window(driver.WindowHandles[0]);

                                                                    break;
                                                                } else
                                                                {
                                                                    Thread.Sleep(5000);
                                                                    err++;
                                                                }
                                                                if (err > 10)
                                                                {
                                                                    break;
                                                                }
                                                            }***/
                                                            Thread.Sleep(20000);
                                                            duangua(driver);
                                                            break;

                                                        }
                                                    }
                                                    else
                                                    {
                                                        repeated_onions(driver, "captcha-solver-info", "class", "", 1);
                                                        
                                                    }
                                                }

                                                   // MessageBox.Show("OK");
                                                   // if(driver.PageSource.Contains("RentService: the Pega is rented by other"))
                                                  //  {
                                                   //     MessageBox.Show("Rent ngựa thất bại!");
                                                 //   }
                                                
                                            }

                                               
                                            
                                           
                                        }
                                    }
                                    break;
                                }
                            }


                        }
                        
                    }
                    driver.Navigate().GoToUrl("https://play.pegaxy.io/renting?tab=share-profit");
                    Thread.Sleep(3000);
                } catch
                {
                    Thread.Sleep(10000);
                }

            }
           

        }


        private void duangua(ChromeDriver driver)
        {
            /***while (true)
            {
                driver.Navigate().GoToUrl("https://play.pegaxy.io/racing/pick-pega");
                Thread.Sleep(2000);
                int a = 0;
                while (true)
                {
                    a++;
                    try
                    {
                        driver.ExecuteScript("document.querySelector(\"#__next > div.root > div.container > div > div.bx-right.fixed > div.bx-content.default > div > div > div > div > div:nth-child(" + a + ")\").click();");
                        Thread.Sleep(500);
                    }
                    catch
                    {
                        break;
                    }
                }
                repeated_onions(driver, "viewButton", "class", "", 10);
                int sleep = 0;
                bool ok = false;
                while (true)
                {
                    try
                    {
                        driver.SwitchTo().Window(driver.WindowHandles[1]);
                        ok = true;
                        break;
                    }
                    catch
                    {
                        sleep++;
                        Thread.Sleep(2000);
                    }
                    if (sleep > 20)
                    {
                        driver.Navigate().GoToUrl("https://play.pegaxy.io/racing/pick-pega");
                        break;
                    }
                }
                if (ok)
                {
                    repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div[3]/button[2]", "click", "", 10);
                    driver.SwitchTo().Window(driver.WindowHandles[0]);
                    bool istrue = true;
                    for(int i = 0; i < 20; i++)
                    {
                        try
                        {
                            driver.FindElement(By.XPath("/html/body/div[3]/div/div/div/div/div[3]/div[1]/div/div[2]")).Click();
                            istrue = false;
                            break;
                        } catch
                        {
                            Thread.Sleep(2000);
                        }
                    }
                    MessageBox.Show(Convert.ToString(istrue));
                    if (istrue)
                    {
                        repeated_onions(driver, "//*[@id=\"__next\"]/div[1]/div[2]/div/div/div[2]/div/div/div[1]/div[2]/div[1]/div/div[2]/div/span", "click", "", 80);
                    }
                    
                    break;
                }
                else
                {
                    break;
                }
            }***/
            while (true)
            {




                // nava
                driver.Navigate().GoToUrl("https://play.pegaxy.io/racing/pick-pega");
                // sec horse
                int a = 0;
                Thread.Sleep(5000);
                while (true)
                {
                    a++;
                    try
                    {
                        driver.ExecuteScript("document.querySelector(\"#__next > div.root > div.container > div > div.bx-right.fixed > div.bx-content.default > div > div > div > div > div:nth-child(" + a + ")\").click();");
                        Thread.Sleep(500);
                    }
                    catch
                    {
                        break;
                    }
                }
                Thread.Sleep(5000);
                // engry 
                if (engry_horse(driver).Contains("00") == false)
                {

                    // click race
                    
                    bool clickrace = repeated_onions(driver, "//*[@id=\"__next\"]/div[1]/div[2]/div/div[1]/div[2]/div/div[2]/div[2]/div[2]/span", "click", "", 10);
                    if (clickrace)
                    {
                        if (driver.PageSource.Contains("Your pega ran out of energy. Each energy will be recovered per hour.") == true || driver.PageSource.Contains("You don't have any available Pegas yet. Required at least one to join racing") == true)
                        {
                            break;
                        } else
                        {
                            Thread.Sleep(5000);
                            bool check = false;
                            for (int i = 0; i < 10; i++)
                            {
                                try
                                {
                                    driver.SwitchTo().Window(driver.WindowHandles[1]);
                                    check = true;
                                    break;
                                }
                                catch
                                {
                                    Thread.Sleep(2000);
                                }
                            }

                            if (check)
                            {
                                repeated_onions(driver, "//*[@id=\"app-content\"]/div/div[2]/div/div[3]/button[2]", "click", "", 10);
                            }
                            else
                            {
                                break;
                            }


                            for (int i = 0; i < 10; i++)
                            {
                                try
                                {
                                    driver.SwitchTo().Window(driver.WindowHandles[0]);
                                    break;
                                }
                                catch
                                {
                                    Thread.Sleep(2000);
                                }
                            }
                            if (driver.PageSource.Contains("NOTICE") != true)
                            {
                                repeated_onions(driver, "//*[@id=\"__next\"]/div[1]/div[2]/div/div/div[2]/div/div/div[1]/div[2]/div[1]/div/div[2]/div/span", "click", "", 60);

                            }

                        }
                    }
                    else
                    {
                       
                        break;
                    }

                } else
                {
                    break;
                }
                
                





            }


        }


        private string engry_horse(ChromeDriver driver)
        {
            IJavaScriptExecutor js = driver as IJavaScriptExecutor;
            string data = (string)js.ExecuteScript("var data = document.querySelector(\"#__next > div.root > div.container > div > div.bx-left > div.bx-content.default > div > div.infoPega > div.pega-info > div.viewInfo > div.viewInfo-content > div > div.mb-3 > div > div > div.list-enegy > div > span\").innerHTML; return data;");
            return data;

        }
        private bool loopcheck (ChromeDriver driver , string text,int count)
        {
            for (int i = 0; i < count; i++)
            {
                if (driver.PageSource.Contains(text))
                {
                    return true;
                } else
                {
                    Thread.Sleep(2000);
                }
            }
            return false;
        }
        private void btn_view_html_Click(object sender, EventArgs e)
        {
            loc_url(driver_specified);
                
        }

        private Dictionary<string, int> loc_url(ChromeDriver driver_specified)
        {
           
            List<string> list = new List<string>();
            try
            {

                // thực thi JavaScript dùng IJavaScriptExecutor
                IJavaScriptExecutor js = driver_specified as IJavaScriptExecutor;
                // javascript cần return giá trị.
                int stt = 0;
                while (true)
                {
                    stt++;
                    try
                    {
                        var dataFromJS = (string)js.ExecuteScript("var content = document.querySelector(\"#__next > div.root > div.container > div > div > div.bx-content.default > div > div > div.list-pick > div:nth-child(" + stt + ")\").innerHTML;return content;");
                        list.Add(dataFromJS);
                    }
                    catch
                    {
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            Dictionary<string, int> dict = new Dictionary<string, int>();
            foreach (string cons in list)
            {
                string[] path = cons.Split("<a href=\"");
                string[] path_2 = path[1].Split("\"");
                string url = "https://play.pegaxy.io" + path_2[0];
                string[] pt1 = cons.Split("% for you");
                string[] pt2 = pt1[0].Split("18px;\">");
                string rent_ngua = (string)json["rent_ngua"];
                string min = rent_ngua.Split("-")[0];
                string max = rent_ngua.Split("-")[1];
                if(Convert.ToInt32(pt2[1]) <= Convert.ToInt32(max))
                {
                    if(Convert.ToInt32(pt2[1]) >= Convert.ToInt32(min))
                    {
                       // MessageBox.Show(pt2[1]);
                        dict.Add(url, Convert.ToInt32(pt2[1]));
                    }
                }
            }
            return dict;
        }
      
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        // move meta extension
        private void btn_move_meta_Click(object sender, EventArgs e)
        {
            try
            {
                driver_specified.Navigate().GoToUrl("https://chrome.google.com/webstore/detail/metamask/nkbihfbeogaeaoehlefnkodbefgpgknn");
            } catch
            {

            }
            
        }

        private void btn_tile_ne_Click(object sender, EventArgs e)
        {
            Dictionary<string, int> VAR_CHECKTILE = loc_url(driver_specified);
            foreach (KeyValuePair<string,int> items in VAR_CHECKTILE)
            {
                MessageBox.Show(Convert.ToString("Đường dẫn con ngựa: " + items.Key + "|Tỉ lệ: " + items.Value));
            }
        }

        private void re_auto_input_Click(object sender, EventArgs e)
        {

        }
    }
}
