﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class editmore : Form
    {
        static string old_char = "";
        static setting options = new setting();
        public editmore(string old)
        {
            old_char = old;
            options.old_char = old;
            InitializeComponent();
        }

        private void editmore_Load(object sender, EventArgs e)
        {
            lb_info_dd.Text = "Dinh dang: duongdan_profile|proxy|meta_wallet|pass_meta|api2captcha|ngay_tao|phan_tram";
            txb_edit.Text = old_char;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            options.new_char = txb_edit.Text;
            options.update_profile();
            MessageBox.Show("Update success!","Thanh cong",MessageBoxButtons.OK,MessageBoxIcon.Information);
            this.Close();
        }
    }
}
