﻿namespace PEGAXY
{
    partial class giaodien_setting
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.nud_delayreload = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.nud_delaybrowser = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_reload = new System.Windows.Forms.Button();
            this.btn_edit_more = new System.Windows.Forms.Button();
            this.lb_profile = new System.Windows.Forms.ListBox();
            this.btn_edit_phantram = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_delayreload)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_delaybrowser)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Setting GUI";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.nud_delayreload);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.nud_delaybrowser);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(12, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(207, 401);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Setting";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // nud_delayreload
            // 
            this.nud_delayreload.Location = new System.Drawing.Point(87, 44);
            this.nud_delayreload.Name = "nud_delayreload";
            this.nud_delayreload.Size = new System.Drawing.Size(61, 23);
            this.nud_delayreload.TabIndex = 3;
            this.nud_delayreload.ValueChanged += new System.EventHandler(this.nud_delayreload_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 15);
            this.label3.TabIndex = 2;
            this.label3.Text = "Delay reload:";
            // 
            // nud_delaybrowser
            // 
            this.nud_delaybrowser.Location = new System.Drawing.Point(130, 20);
            this.nud_delaybrowser.Name = "nud_delaybrowser";
            this.nud_delaybrowser.Size = new System.Drawing.Size(61, 23);
            this.nud_delaybrowser.TabIndex = 1;
            this.nud_delaybrowser.ValueChanged += new System.EventHandler(this.nud_delaybrowser_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(121, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Delay mở trình duyệt:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_reload);
            this.groupBox2.Controls.Add(this.btn_edit_more);
            this.groupBox2.Controls.Add(this.lb_profile);
            this.groupBox2.Controls.Add(this.btn_edit_phantram);
            this.groupBox2.Location = new System.Drawing.Point(225, 37);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(228, 425);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Chỉnh sửa";
            // 
            // btn_reload
            // 
            this.btn_reload.Location = new System.Drawing.Point(6, 396);
            this.btn_reload.Name = "btn_reload";
            this.btn_reload.Size = new System.Drawing.Size(90, 23);
            this.btn_reload.TabIndex = 3;
            this.btn_reload.Text = "Tai lai";
            this.btn_reload.UseVisualStyleBackColor = true;
            this.btn_reload.Click += new System.EventHandler(this.btn_reload_Click);
            // 
            // btn_edit_more
            // 
            this.btn_edit_more.Location = new System.Drawing.Point(102, 396);
            this.btn_edit_more.Name = "btn_edit_more";
            this.btn_edit_more.Size = new System.Drawing.Size(120, 23);
            this.btn_edit_more.TabIndex = 2;
            this.btn_edit_more.Text = "Edit more";
            this.btn_edit_more.UseVisualStyleBackColor = true;
            this.btn_edit_more.Click += new System.EventHandler(this.btn_edit_more_Click);
            // 
            // lb_profile
            // 
            this.lb_profile.FormattingEnabled = true;
            this.lb_profile.ItemHeight = 15;
            this.lb_profile.Location = new System.Drawing.Point(6, 22);
            this.lb_profile.Name = "lb_profile";
            this.lb_profile.Size = new System.Drawing.Size(216, 349);
            this.lb_profile.TabIndex = 1;
            this.lb_profile.SelectedIndexChanged += new System.EventHandler(this.lb_profile_SelectedIndexChanged);
            // 
            // btn_edit_phantram
            // 
            this.btn_edit_phantram.Location = new System.Drawing.Point(6, 372);
            this.btn_edit_phantram.Name = "btn_edit_phantram";
            this.btn_edit_phantram.Size = new System.Drawing.Size(216, 23);
            this.btn_edit_phantram.TabIndex = 0;
            this.btn_edit_phantram.Text = "Chinh sua phan tram";
            this.btn_edit_phantram.UseVisualStyleBackColor = true;
            this.btn_edit_phantram.Click += new System.EventHandler(this.btn_edit_phantram_Click);
            // 
            // giaodien_setting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(465, 474);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "giaodien_setting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Giao diện setting";
            this.Load += new System.EventHandler(this.giaodien_setting_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud_delayreload)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_delaybrowser)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private NumericUpDown nud_delayreload;
        private Label label3;
        private NumericUpDown nud_delaybrowser;
        private Label label2;
        private GroupBox groupBox2;
        private ListBox lb_profile;
        private Button btn_edit_phantram;
        private Button btn_edit_more;
        private Button btn_reload;
    }
}