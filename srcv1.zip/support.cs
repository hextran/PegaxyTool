﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PEGAXY
{
    internal class support
    {

        /// <summary>
        /// Random chữ bất kì
        /// </summary>
        /// <param name="min"></param>
        /// <param name="max"></param>
        /// <returns></returns>
        public string random_string(int min, int max)
        {
            Random rand = new Random();

            // Choosing the size of string
            // Using Next() string
            int stringlen = rand.Next(min, max);
            int randValue;
            string str = "";
            char letter;
            for (int i = 0; i < stringlen; i++)
            {

                // Generating a random number.
                randValue = rand.Next(0, 26);

                // Generating random character by converting
                // the random number into character.
                letter = Convert.ToChar(randValue + 65);

                // Appending the letter to string.
                str = str + letter;
            }
            return str;
        }
        /// <summary>
        /// Xóa folder
        /// </summary>
        /// <param name="path"></param>
        public void DeleteFolder(string path)
        {
            DirectoryInfo dir2delete = new DirectoryInfo(path);
            foreach (FileInfo file in dir2delete.GetFiles())
            {
                file.Delete();
            }
            foreach (DirectoryInfo dir in dir2delete.GetDirectories())
            {
                dir.Delete(true);
            }
        }

        public string StripHtml(string Txt)
        {
            return Regex.Replace(Txt, "<(.|\\n)*?>", string.Empty);
        }
    }
}
