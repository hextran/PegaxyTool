﻿using Newtonsoft.Json.Linq;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PEGAXY
{
    public partial class startdriver : Form
    {
        static ChromeDriver drivers = null;
        static Object infoz = null;
        static int thread_set = 0;
        public startdriver(ChromeDriver driver, JObject info, int thread)
        {
            drivers = driver;
            infoz = info;
            thread_set = thread;
            InitializeComponent();
        }

        private void startdriver_Load(object sender, EventArgs e)
        {
            lb_info_running.Text = "Status threads: " + thread_set;
        }
    }
}
