﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PEGAXY
{
  
    internal class setting
    {
        static profile pro = new profile();
        public string old_char { get; set; }
        public string new_char { get; set; }
        

        public void update_profile()
        {
            pro.update_profile(old_char, new_char);
        }

        public string load_browser_delay()
        {
            return File.ReadAllText("delaybrowser.txt");
        }

        public string load_reload_delay()
        {
            return File.ReadAllText("delayreload.txt");
        }
    }
}
